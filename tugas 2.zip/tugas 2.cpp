#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 100

// Stack Array
typedef struct {
    char data[MAX_SIZE];
    int top;
} StackArray;

void pushArray(StackArray *stack, char element) {
    if (stack->top < MAX_SIZE - 1) {
        stack->top++;
        stack->data[stack->top] = element;
    } else {
        printf("Stack overflow\n");
        exit(1);
    }
}

char popArray(StackArray *stack) {
    char element = '\0';
    if (stack->top >= 0) {
        element = stack->data[stack->top];
        stack->top--;
    } else {
        printf("Stack underflow\n");
        exit(1);
    }
    return element;
}

// Stack Linked List
typedef struct node {
    char data;
    struct node *next;
} node;

typedef struct {
    node *top;
} StackLinkedList;

void pushLinkedList(StackLinkedList *stack, char element) {
    node *newNode = (node *)malloc(sizeof(node));
    if (newNode == NULL) {
        printf("Memory allocation error\n");
        exit(1);
    }
    newNode->data = element;
    newNode->next = stack->top;
    stack->top = newNode;
}

char popLinkedList(StackLinkedList *stack) {
    char element = '\0';
    if (stack->top != NULL) {
        element = stack->top->data;
        node *temp = stack->top;
        stack->top = stack->top->next;
        free(temp);
    } else {
        printf("Stack underflow\n");
        exit(1);
    }
    return element;
}

// Stack String untuk Postfix ke Infix
typedef struct nodeString {
    char *data;
    struct nodeString *next;
} nodeString;

typedef struct {
    nodeString *top;
} StackString;

void pushString(StackString *stack, char *element) {
    nodeString *newNode = (nodeString *)malloc(sizeof(nodeString));
    if (newNode == NULL) {
        printf("Memory allocation error\n");
        exit(1);
    }
    newNode->data = strdup(element); 
    newNode->next = stack->top;
    stack->top = newNode;
}

char *popString(StackString *stack) {
    char *element = NULL;
    if (stack->top != NULL) {
        element = stack->top->data;
        nodeString *temp = stack->top;
        stack->top = stack->top->next;
        free(temp); 
    } else {
        printf("Stack underflow\n");
        exit(1);
    }
    return element;
}

int isOperator(char symbol) {
    return (symbol == '+' || symbol == '-' || symbol == '*' || symbol == '/');
}

int precedence(char op) {
    switch (op) {
        case '+':
        case '-':
            return 1;
        case '*':
        case '/':
            return 2;
        default:
            return 0;
    }
}

void infixToPostfixArray(char infix[], char postfix[]) {
    StackArray stack;
    stack.top = -1;
    int i = 0, j = 0;

    while (infix[i] != '\0' && infix[i] != '\n') {
        if (infix[i] == ' ') {
            i++;
            continue;
        }

        if (!isOperator(infix[i])) {
            postfix[j++] = infix[i];
        } else {
            while (stack.top >= 0 && precedence(stack.data[stack.top]) >= precedence(infix[i])) {
                postfix[j++] = popArray(&stack);
            }
            pushArray(&stack, infix[i]);
        }

        i++;
    }

    while (stack.top >= 0) {
        postfix[j++] = popArray(&stack);
    }

    postfix[j] = '\0';
}

void infixToPostfixLinkedList(char infix[], char postfix[]) {
    StackLinkedList stack;
    stack.top = NULL;
    int i = 0, j = 0;

    while (infix[i] != '\0' && infix[i] != '\n') {
        if (infix[i] == ' ') {
            i++;
            continue;
        }

        if (!isOperator(infix[i])) {
            postfix[j++] = infix[i];
        } else {
            while (stack.top != NULL && precedence(stack.top->data) >= precedence(infix[i])) {
                postfix[j++] = popLinkedList(&stack);
            }
            pushLinkedList(&stack, infix[i]);
        }

        i++;
    }

    while (stack.top != NULL) {
        postfix[j++] = popLinkedList(&stack);
    }

    postfix[j] = '\0';
}

void postfixToInfixString(char postfix[], char infix[]) {
    StackString stack;
    stack.top = NULL;
    int i = 0;

    while (postfix[i] != '\0' && postfix[i] != '\n') {
        if (postfix[i] == ' ') {
            i++;
            continue;
        }

        if (!isOperator(postfix[i])) {
            char temp[2] = {postfix[i], '\0'};
            pushString(&stack, temp);
        } else {
            char *operand2 = popString(&stack);
            char *operand1 = popString(&stack);

            char temp[10];
            sprintf(temp, "(%s%c%s)", operand1, postfix[i], operand2);
            pushString(&stack, temp);

            free(operand1);
            free(operand2); 
        }

        i++;
    }

    
    char *result = popString(&stack);
    strcpy(infix, result);
    free(result); 
}

int main() {
    char infix[MAX_SIZE], postfix[MAX_SIZE], infixResult[MAX_SIZE];

    printf("Masukkan ekspresi infix: ");
    fgets(infix, sizeof(infix), stdin);

    printf("Pilih metode konversi:\n1. Array\n2. Linked List\n");
    int choice;
    scanf("%d", &choice);
    getchar(); 

    if (choice == 1) {
        infixToPostfixArray(infix, postfix);
    } else if (choice == 2) {
        infixToPostfixLinkedList(infix, postfix);
    } else {
        printf("Pilihan tidak valid\n");
        return 1;
    }

    printf("Ekspresi postfix: %s\n", postfix);

    postfixToInfixString(postfix, infixResult);
    printf("Ekspresi infix dari postfix: %s\n", infixResult);

    return 0;
}
